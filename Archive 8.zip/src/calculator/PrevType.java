package calculator;

enum PrevType {
  EMPTY, DIGIT, OPERATOR, EQUAL
}
